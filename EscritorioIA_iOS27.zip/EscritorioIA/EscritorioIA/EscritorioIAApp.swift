import SwiftUI

@main
struct EscritorioIAApp: App {
    @AppStorage("oscuro") private var oscuro = true
    @State private var escritorio: Escritorio
    @State private var asistente: Asistente

    init() {
        let e = Escritorio()
        _escritorio = State(initialValue: e)
        _asistente = State(initialValue: Asistente(escritorio: e))
    }

    var body: some Scene {
        WindowGroup {
            EscritorioView()
                .environment(escritorio)
                .environment(asistente)
                .preferredColorScheme(oscuro ? .dark : .light)
        }
    }
}
