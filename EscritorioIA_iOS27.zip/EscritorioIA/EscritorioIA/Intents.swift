import AppIntents
import FoundationModels

enum ErrorIA: Error, CustomLocalizedStringResourceConvertible {
    case noDisponible
    var localizedStringResource: LocalizedStringResource {
        "Apple Intelligence no está disponible en este dispositivo."
    }
}

struct PreguntarIntent: AppIntent {
    static var title: LocalizedStringResource = "Preguntar al asistente"
    @Parameter(title: "Pregunta") var pregunta: String

    func perform() async throws -> some IntentResult & ReturnsValue<String> & ProvidesDialog {
        guard case .available = SystemLanguageModel.default.availability else { throw ErrorIA.noDisponible }
        let s = LanguageModelSession(instructions: "Responde en español, en pocas frases.")
        let r = try await s.respond(to: pregunta)
        return .result(value: r.content, dialog: IntentDialog(stringLiteral: r.content))
    }
}

struct GuardarNotaIntent: AppIntent {
    static var title: LocalizedStringResource = "Guardar nota"
    @Parameter(title: "Texto") var texto: String

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let d = UserDefaults.standard
        let actual = d.string(forKey: "notas") ?? ""
        d.set(actual.isEmpty ? texto : actual + "\n" + texto, forKey: "notas")
        return .result(dialog: "Nota guardada.")
    }
}

struct AtajosApp: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: PreguntarIntent(),
                    phrases: ["Pregunta a \(.applicationName)", "Hablar con \(.applicationName)"],
                    shortTitle: "Preguntar", systemImageName: "sparkles")
        AppShortcut(intent: GuardarNotaIntent(),
                    phrases: ["Guardar nota en \(.applicationName)"],
                    shortTitle: "Guardar nota", systemImageName: "note.text")
    }
}
