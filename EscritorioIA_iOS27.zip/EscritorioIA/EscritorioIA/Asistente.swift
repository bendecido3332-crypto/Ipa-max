import SwiftUI
import FoundationModels
import AVFoundation
import Speech

// MARK: - Herramientas que el modelo puede llamar

struct AbrirAppTool: Tool {
    let name = "abrir_app"
    let description = "Abre una app del escritorio. Nombres válidos: " + AppID.allCases.map(\.rawValue).joined(separator: ", ")
    let escritorio: Escritorio

    @Generable
    struct Arguments {
        @Guide(description: "Nombre de la app a abrir")
        let app: String
    }

    func call(arguments: Arguments) async throws -> String {
        let ok = await escritorio.abrir(nombre: arguments.app)
        return ok ? "Listo, abrí \(arguments.app)." : "Esa app no existe."
    }
}

struct GuardarNotaTool: Tool {
    let name = "guardar_nota"
    let description = "Guarda un texto en la app Notas."

    @Generable
    struct Arguments {
        @Guide(description: "Texto de la nota")
        let texto: String
    }

    func call(arguments: Arguments) async throws -> String {
        let d = UserDefaults.standard
        let actual = d.string(forKey: "notas") ?? ""
        d.set(actual.isEmpty ? arguments.texto : actual + "\n" + arguments.texto, forKey: "notas")
        return "Nota guardada."
    }
}

// MARK: - Asistente (chat + voz)

@Observable @MainActor
final class Asistente {
    struct Mensaje: Identifiable { let id = UUID(); let esUsuario: Bool; let texto: String }

    var mensajes: [Mensaje] = []
    var borrador = ""
    var pensando = false
    var escuchando = false
    var hablar = true
    var aviso: String?

    private var sesion: LanguageModelSession?
    private let voz = AVSpeechSynthesizer()
    private let reconocedor = Reconocedor()

    init(escritorio: Escritorio) {
        switch SystemLanguageModel.default.availability {
        case .available:
            sesion = LanguageModelSession(
                tools: [AbrirAppTool(escritorio: escritorio), GuardarNotaTool()],
                instructions: "Eres un asistente breve y amable. Responde siempre en español. Puedes abrir apps del escritorio y guardar notas usando tus herramientas."
            )
        case .unavailable(let motivo):
            aviso = "Apple Intelligence no está disponible (\(motivo))."
        }
    }

    func enviar(_ texto: String) async {
        let t = texto.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, let sesion, !pensando else { return }
        mensajes.append(.init(esUsuario: true, texto: t))
        pensando = true
        defer { pensando = false }
        do {
            let r = try await sesion.respond(to: t)
            mensajes.append(.init(esUsuario: false, texto: r.content))
            if hablar { decir(r.content) }
        } catch {
            mensajes.append(.init(esUsuario: false, texto: "Error: \(error.localizedDescription)"))
        }
    }

    func alternarMicrofono() async {
        if escuchando { reconocedor.detener(); return }
        voz.stopSpeaking(at: .immediate)
        guard await Reconocedor.pedirPermisos() else {
            aviso = "Activa micrófono y reconocimiento de voz en Ajustes de iOS."
            return
        }
        do {
            escuchando = true
            try reconocedor.iniciar { [weak self] texto, fin in
                Task { @MainActor in
                    guard let self else { return }
                    if !texto.isEmpty { self.borrador = texto }
                    if fin {
                        self.escuchando = false
                        let t = self.borrador
                        self.borrador = ""
                        await self.enviar(t)
                    }
                }
            }
        } catch {
            escuchando = false
            aviso = "No se pudo iniciar el micrófono."
        }
    }

    private func decir(_ texto: String) {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .spokenAudio)
        try? s.setActive(true)
        let u = AVSpeechUtterance(string: texto)
        u.voice = AVSpeechSynthesisVoice(language: "es-ES")
        voz.speak(u)
    }
}

// MARK: - Reconocimiento de voz

final class Reconocedor {
    private let motor = AVAudioEngine()
    private let reconocedor = SFSpeechRecognizer(locale: Locale(identifier: "es-ES"))
    private var peticion: SFSpeechAudioBufferRecognitionRequest?
    private var tarea: SFSpeechRecognitionTask?

    static func pedirPermisos() async -> Bool {
        let voz = await withCheckedContinuation { c in
            SFSpeechRecognizer.requestAuthorization { c.resume(returning: $0 == .authorized) }
        }
        let mic = await AVAudioApplication.requestRecordPermission()
        return voz && mic
    }

    func iniciar(alCambiar: @escaping @Sendable (String, Bool) -> Void) throws {
        let audio = AVAudioSession.sharedInstance()
        try audio.setCategory(.record, mode: .measurement, options: .duckOthers)
        try audio.setActive(true, options: .notifyOthersOnDeactivation)
        let p = SFSpeechAudioBufferRecognitionRequest()
        p.shouldReportPartialResults = true
        peticion = p
        let entrada = motor.inputNode
        entrada.installTap(onBus: 0, bufferSize: 1024, format: entrada.outputFormat(forBus: 0)) { buffer, _ in
            p.append(buffer)
        }
        motor.prepare()
        try motor.start()
        tarea = reconocedor?.recognitionTask(with: p) { [weak self] r, e in
            let fin = r?.isFinal == true || e != nil
            alCambiar(r?.bestTranscription.formattedString ?? "", fin)
            if fin { self?.detener() }
        }
    }

    func detener() {
        if motor.isRunning { motor.stop(); motor.inputNode.removeTap(onBus: 0) }
        peticion?.endAudio()
        peticion = nil
        tarea = nil
    }
}
