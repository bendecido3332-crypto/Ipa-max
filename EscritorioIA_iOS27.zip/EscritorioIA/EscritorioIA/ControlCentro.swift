import SwiftUI
import AVFoundation
import MediaPlayer

// MARK: - Centro de control (Liquid Glass)

struct ControlCentro: View {
    @Environment(Escritorio.self) private var escritorio
    @Environment(Asistente.self) private var asistente
    @AppStorage("oscuro") private var oscuro = true
    @State private var brillo = 0.5
    @State private var linterna = false

    private var pantalla: UIScreen? { (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.screen }
    private let forma = RoundedRectangle(cornerRadius: 24, style: .continuous)

    var body: some View {
        @Bindable var a = asistente
        GlassEffectContainer(spacing: 12) {
            VStack(spacing: 12) {
                HStack(spacing: 12) {
                    baldosa("Modo", oscuro ? "moon.fill" : "sun.max.fill", oscuro) { oscuro.toggle() }
                    baldosa("Linterna", "flashlight.on.fill", linterna) { alternarLinterna() }
                    baldosa("Voz", "speaker.wave.2.fill", a.hablar) { a.hablar.toggle() }
                }
                fila("sun.max.fill") {
                    Slider(value: $brillo, in: 0.05...1)
                        .onChange(of: brillo) { _, v in pantalla?.brightness = v }
                }
                fila("speaker.fill") { VolumenView().frame(height: 30) }
                HStack(spacing: 12) {
                    ForEach([AppID.calculadora, .notas, .navegador, .reloj]) { app in
                        Button {
                            escritorio.abrir(app)
                            withAnimation(.spring) { escritorio.controlAbierto = false }
                        } label: {
                            Image(systemName: app.icono).font(.title2).frame(maxWidth: .infinity, minHeight: 56)
                        }
                        .buttonStyle(.plain)
                        .glassEffect(.regular.interactive(), in: forma)
                    }
                }
            }
        }
        .padding(14)
        .frame(maxWidth: 340)
        .onAppear { brillo = Double(pantalla?.brightness ?? 0.5) }
    }

    private func baldosa(_ titulo: String, _ icono: String, _ activo: Bool, _ accion: @escaping () -> Void) -> some View {
        Button(action: accion) {
            VStack(spacing: 6) {
                Image(systemName: icono).font(.title2)
                Text(titulo).font(.caption2)
            }
            .frame(maxWidth: .infinity, minHeight: 72)
        }
        .buttonStyle(.plain)
        .glassEffect(activo ? Glass.regular.tint(.orange).interactive() : Glass.regular.interactive(), in: forma)
    }

    private func fila<C: View>(_ icono: String, @ViewBuilder _ contenido: () -> C) -> some View {
        HStack(spacing: 10) { Image(systemName: icono); contenido() }
            .padding(.horizontal, 16)
            .frame(height: 52)
            .glassEffect(.regular, in: Capsule())
    }

    private func alternarLinterna() {
        guard let d = AVCaptureDevice.default(for: .video), d.hasTorch else { return }
        let nuevo = !linterna
        try? d.lockForConfiguration()
        d.torchMode = nuevo ? .on : .off
        d.unlockForConfiguration()
        linterna = nuevo
    }
}

struct VolumenView: UIViewRepresentable {
    func makeUIView(context: Context) -> MPVolumeView { MPVolumeView(frame: .zero) }
    func updateUIView(_ v: MPVolumeView, context: Context) {}
}

// MARK: - Calendario y Reloj

struct CalendarioView: View {
    @State private var fecha = Date()

    var body: some View {
        VStack {
            DatePicker("", selection: $fecha, displayedComponents: .date)
                .datePickerStyle(.graphical).labelsHidden().padding(8)
            Text(fecha.formatted(date: .complete, time: .omitted)).font(.footnote)
            Spacer()
        }
    }
}

struct RelojView: View {
    @State private var inicio: Date?
    @State private var acumulado: TimeInterval = 0

    var body: some View {
        VStack(spacing: 16) {
            TimelineView(.periodic(from: .now, by: 1)) { c in
                Text(c.date, format: .dateTime.hour().minute().second())
                    .font(.system(size: 44, weight: .thin, design: .rounded)).monospacedDigit()
            }
            Divider()
            TimelineView(.animation(minimumInterval: 0.05)) { c in
                let t = acumulado + (inicio.map { c.date.timeIntervalSince($0) } ?? 0)
                Text(String(format: "%02d:%05.2f", Int(t) / 60, t.truncatingRemainder(dividingBy: 60)))
                    .font(.system(size: 36, weight: .light, design: .monospaced))
            }
            HStack {
                Button(inicio == nil ? "Iniciar" : "Pausar") {
                    if let i = inicio { acumulado += Date().timeIntervalSince(i); inicio = nil } else { inicio = Date() }
                }
                Button("Reiniciar") { inicio = nil; acumulado = 0 }
            }
            .buttonStyle(.glass)
        }
        .frame(maxHeight: .infinity)
    }
}
