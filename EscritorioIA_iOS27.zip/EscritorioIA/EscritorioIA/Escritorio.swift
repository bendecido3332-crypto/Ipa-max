import SwiftUI

enum AppID: String, CaseIterable, Identifiable {
    case asistente, notas, calculadora, navegador, archivos, terminal, monitor, calendario, reloj, ajustes
    var id: String { rawValue }
    var titulo: String {
        switch self {
        case .asistente: "Asistente"
        case .notas: "Notas"
        case .calculadora: "Calculadora"
        case .navegador: "Navegador"
        case .archivos: "Archivos"
        case .terminal: "Terminal"
        case .monitor: "Monitor"
        case .calendario: "Calendario"
        case .reloj: "Reloj"
        case .ajustes: "Ajustes"
        }
    }
    var icono: String {
        switch self {
        case .asistente: "sparkles"
        case .notas: "note.text"
        case .calculadora: "plusminus.circle.fill"
        case .navegador: "safari.fill"
        case .archivos: "folder.fill"
        case .terminal: "terminal.fill"
        case .monitor: "chart.bar.fill"
        case .calendario: "calendar"
        case .reloj: "clock.fill"
        case .ajustes: "gearshape.fill"
        }
    }
    var colores: [Color] {
        switch self {
        case .asistente: [.purple, .indigo]
        case .notas: [.yellow, .orange]
        case .calculadora: [Color(white: 0.4), Color(white: 0.12)]
        case .navegador: [.cyan, .blue]
        case .archivos: [.teal, .blue]
        case .terminal: [Color(white: 0.3), .black]
        case .monitor: [.green, .mint]
        case .calendario: [.pink, .red]
        case .reloj: [Color(white: 0.25), .black]
        case .ajustes: [Color(white: 0.7), Color(white: 0.4)]
        }
    }
}

// Icono original estilo "squircle" con degradado y brillo
struct Icono: View {
    let simbolo: String
    let colores: [Color]
    var tam: CGFloat = 52

    init(app: AppID, tam: CGFloat = 52) { simbolo = app.icono; colores = app.colores; self.tam = tam }
    init(simbolo: String, colores: [Color], tam: CGFloat = 52) { self.simbolo = simbolo; self.colores = colores; self.tam = tam }

    var body: some View {
        let forma = RoundedRectangle(cornerRadius: tam * 0.225, style: .continuous)
        ZStack {
            forma.fill(LinearGradient(colors: colores, startPoint: .top, endPoint: .bottom))
            forma.strokeBorder(LinearGradient(colors: [.white.opacity(0.55), .clear], startPoint: .top, endPoint: .bottom), lineWidth: 1)
            Image(systemName: simbolo)
                .font(.system(size: tam * 0.46, weight: .semibold))
                .foregroundStyle(.white)
                .shadow(color: .black.opacity(0.25), radius: 2, y: 1)
        }
        .frame(width: tam, height: tam)
        .shadow(color: .black.opacity(0.3), radius: 4, y: 2)
    }
}

@Observable @MainActor
final class Ventana: Identifiable {
    let id = UUID()
    let app: AppID
    var posicion: CGSize
    var z: Double
    var minimizada = false
    var maximizada = false
    var ancho: CGFloat = 330
    var alto: CGFloat = 440
    init(app: AppID, posicion: CGSize, z: Double) { self.app = app; self.posicion = posicion; self.z = z }
}

@Observable @MainActor
final class Escritorio {
    var ventanas: [Ventana] = []
    var controlAbierto = false
    var lanzador = false
    var busqueda = false
    var vistaGeneral = false
    var area: CGSize = .zero
    private var contador = 0.0

    enum Modo { case izquierda, derecha, arriba, abajo, centro }

    func ajustar(_ v: Ventana, _ m: Modo) {
        let a = area
        let top: CGFloat = 52
        let h = max(a.height - top - 100, 240)
        v.maximizada = false
        switch m {
        case .izquierda:
            v.ancho = max(a.width / 2 - 12, 160); v.alto = h
            v.posicion = CGSize(width: 8, height: top)
        case .derecha:
            v.ancho = max(a.width / 2 - 12, 160); v.alto = h
            v.posicion = CGSize(width: a.width / 2 + 4, height: top)
        case .arriba:
            v.ancho = a.width - 16; v.alto = max(h / 2 - 4, 160)
            v.posicion = CGSize(width: 8, height: top)
        case .abajo:
            v.ancho = a.width - 16; v.alto = max(h / 2 - 4, 160)
            v.posicion = CGSize(width: 8, height: top + h / 2 + 4)
        case .centro:
            v.posicion = CGSize(width: max((a.width - v.ancho) / 2, 0), height: top + 20)
        }
        frente(v)
    }

    func abrir(_ app: AppID) {
        if let v = ventanas.first(where: { $0.app == app }) {
            v.minimizada = false
            frente(v)
            return
        }
        contador += 1
        let w = Ventana(app: app, posicion: CGSize(width: 16 + contador * 10, height: 110 + contador * 14), z: contador)
        if area.width > 600 { w.ancho = 480; w.alto = 540 }
        ventanas.append(w)
    }
    func abrir(nombre: String) -> Bool {
        guard let app = AppID(rawValue: nombre.lowercased()) else { return false }
        abrir(app)
        return true
    }
    func frente(_ v: Ventana) { contador += 1; v.z = contador }
    func cerrar(_ v: Ventana) { ventanas.removeAll { $0.id == v.id } }
}

struct EscritorioView: View {
    @Environment(Escritorio.self) private var e
    @AppStorage("fondo") private var fondo = 0

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                LinearGradient(colors: Fondos.colores[min(fondo, Fondos.colores.count - 1)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                WidgetFecha().padding(.top, 56).padding(.trailing, 12).frame(maxWidth: .infinity, alignment: .trailing)
                Button { e.abrir(.archivos) } label: {
                    VStack(spacing: 4) {
                        Icono(simbolo: "internaldrive.fill", colores: [.gray, Color(white: 0.3)], tam: 46)
                        Text("Disco").font(.caption2).foregroundStyle(.white)
                    }
                }
                .buttonStyle(.plain).padding(.top, 56).padding(.leading, 14)

                ForEach(e.ventanas) { v in
                    if !v.minimizada {
                        VentanaView(v: v, area: geo.size)
                            .zIndex(v.z)
                            .transition(.scale.combined(with: .opacity))
                    }
                }
                VStack(spacing: 0) {
                    BarraMenu()
                    Spacer()
                    Dock()
                }
                .zIndex(10_000)

                if e.controlAbierto {
                    Color.black.opacity(0.25).ignoresSafeArea()
                        .onTapGesture { withAnimation(.spring) { e.controlAbierto = false } }
                        .zIndex(15_000)
                    ControlCentro().padding(.top, 48).frame(maxWidth: .infinity)
                        .transition(.move(edge: .top).combined(with: .opacity)).zIndex(20_000)
                }
                if e.busqueda {
                    Color.black.opacity(0.3).ignoresSafeArea()
                        .onTapGesture { withAnimation(.spring) { e.busqueda = false } }
                        .zIndex(25_000)
                    BusquedaView().padding(.top, 60).frame(maxWidth: .infinity)
                        .transition(.move(edge: .top).combined(with: .opacity)).zIndex(26_000)
                }
                if e.vistaGeneral {
                    VistaGeneralView().transition(.opacity).zIndex(28_000)
                }
                if e.lanzador {
                    LanzadorView().transition(.opacity).zIndex(30_000)
                }
            }
            .onAppear { e.area = geo.size }
            .onChange(of: geo.size) { _, n in e.area = n }
            .gesture(DragGesture().onEnded { g in
                if g.startLocation.y < 120 && g.translation.height > 60 {
                    withAnimation(.spring) { e.controlAbierto = true }
                }
            })
        }
    }
}

struct WidgetFecha: View {
    var body: some View {
        TimelineView(.periodic(from: .now, by: 60)) { c in
            VStack(alignment: .leading, spacing: 2) {
                Text(c.date, format: .dateTime.weekday(.wide)).font(.caption.bold()).foregroundStyle(.red)
                Text(c.date, format: .dateTime.day()).font(.system(size: 40, weight: .light))
                Text(c.date, format: .dateTime.month(.wide).year()).font(.caption)
            }
            .padding(12)
            .frame(width: 130, alignment: .leading)
            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        }
    }
}

struct BarraMenu: View {
    @Environment(Escritorio.self) private var e
    private var activa: Ventana? { e.ventanas.filter { !$0.minimizada }.max(by: { $0.z < $1.z }) }

    var body: some View {
        HStack(spacing: 14) {
            Menu {
                Button("Acerca de EscritorioIA", systemImage: "info.circle") { e.abrir(.ajustes) }
                Button("Ajustes…", systemImage: "gearshape") { e.abrir(.ajustes) }
                Divider()
                Button("Cerrar todas las ventanas", systemImage: "xmark.circle", role: .destructive) {
                    withAnimation(.spring) { e.ventanas.removeAll() }
                }
            } label: { Image(systemName: "sparkle") }

            Menu {
                if let v = activa {
                    Button("Cerrar ventana") { withAnimation(.spring) { e.cerrar(v) } }.keyboardShortcut("w")
                    Button("Minimizar") { withAnimation(.spring) { v.minimizada = true } }.keyboardShortcut("m")
                    Button("Maximizar / restaurar") { withAnimation(.spring) { v.maximizada.toggle() } }
                    Menu("Organizar") {
                        Button("Mitad izquierda", systemImage: "rectangle.lefthalf.filled") { withAnimation(.spring) { e.ajustar(v, .izquierda) } }
                        Button("Mitad derecha", systemImage: "rectangle.righthalf.filled") { withAnimation(.spring) { e.ajustar(v, .derecha) } }
                        Button("Mitad superior", systemImage: "rectangle.tophalf.filled") { withAnimation(.spring) { e.ajustar(v, .arriba) } }
                        Button("Mitad inferior", systemImage: "rectangle.bottomhalf.filled") { withAnimation(.spring) { e.ajustar(v, .abajo) } }
                        Button("Centrar", systemImage: "rectangle.center.inset.filled") { withAnimation(.spring) { e.ajustar(v, .centro) } }
                    }
                }
                Section("Ventanas") {
                    ForEach(e.ventanas) { v in Button(v.app.titulo) { e.abrir(v.app) } }
                }
                Section("Abrir") {
                    ForEach(AppID.allCases) { a in Button(a.titulo, systemImage: a.icono) { e.abrir(a) } }
                }
            } label: { Text(activa?.app.titulo ?? "Escritorio").bold() }

            Spacer()
            Button { withAnimation(.spring) { e.vistaGeneral = true } } label: { Image(systemName: "rectangle.3.group") }
                .keyboardShortcut(.upArrow, modifiers: .control)
            Button { withAnimation(.spring) { e.busqueda = true } } label: { Image(systemName: "magnifyingglass") }
                .keyboardShortcut(.space, modifiers: .command)
            Button { withAnimation(.spring) { e.controlAbierto.toggle() } } label: { Image(systemName: "slider.horizontal.3") }
            TimelineView(.periodic(from: .now, by: 30)) { c in
                Text(c.date, format: .dateTime.weekday(.abbreviated).hour().minute())
            }
        }
        .foregroundStyle(.primary)
        .font(.footnote)
        .padding(.horizontal, 16).padding(.vertical, 8)
        .glassEffect(.regular, in: Capsule())
        .padding(.horizontal, 12)
    }
}

struct VentanaView: View {
    @Environment(Escritorio.self) private var e
    let v: Ventana
    let area: CGSize
    @State private var inicio: CGSize?
    @State private var tam0: CGSize?

    private var ancho: CGFloat { v.maximizada ? area.width - 16 : v.ancho }
    private var alto: CGFloat { v.maximizada ? area.height - 150 : v.alto }
    private var pos: CGSize { v.maximizada ? CGSize(width: 8, height: 52) : v.posicion }

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                Text(v.app.titulo).font(.footnote.bold())
                HStack(spacing: 8) {
                    luz(.red, "xmark") { withAnimation(.spring) { e.cerrar(v) } }
                    luz(.yellow, "minus") { withAnimation(.spring) { v.minimizada = true } }
                    luz(.green, v.maximizada ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right") {
                        withAnimation(.spring) { v.maximizada.toggle() }
                    }
                    Spacer()
                }
            }
            .frame(height: 34).padding(.horizontal, 12)
            .gesture(DragGesture()
                .onChanged { g in
                    if v.maximizada { return }
                    if inicio == nil { inicio = v.posicion; e.frente(v) }
                    let b = inicio ?? .zero
                    v.posicion = CGSize(width: b.width + g.translation.width, height: b.height + g.translation.height)
                }
                .onEnded { _ in inicio = nil })

            Group {
                switch v.app {
                case .asistente: AsistenteView()
                case .notas: NotasView()
                case .ajustes: AjustesView()
                case .calculadora: CalculadoraView()
                case .navegador: NavegadorView()
                case .archivos: ArchivosView()
                case .terminal: TerminalView()
                case .monitor: MonitorView()
                case .calendario: CalendarioView()
                case .reloj: RelojView()
                }
            }
        }
        .frame(width: ancho, height: alto)
        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(alignment: .bottomTrailing) {
            if !v.maximizada {
                Image(systemName: "arrow.down.right").font(.caption2.bold()).foregroundStyle(.secondary).padding(10)
                    .gesture(DragGesture()
                        .onChanged { g in
                            let b = tam0 ?? CGSize(width: v.ancho, height: v.alto)
                            tam0 = b
                            v.ancho = min(max(b.width + g.translation.width, 260), 700)
                            v.alto = min(max(b.height + g.translation.height, 260), 700)
                        }
                        .onEnded { _ in tam0 = nil })
            }
        }
        .shadow(radius: 20, y: 8)
        .offset(pos)
        .onTapGesture { e.frente(v) }
    }

    private func luz(_ c: Color, _ icono: String, _ f: @escaping () -> Void) -> some View {
        Button(action: f) {
            Circle().fill(c).frame(width: 14, height: 14)
                .overlay(Image(systemName: icono).font(.system(size: 7, weight: .black)).foregroundStyle(.black.opacity(0.5)))
        }
    }
}

struct Dock: View {
    @Environment(Escritorio.self) private var e

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                Button { withAnimation(.spring) { e.lanzador = true } } label: {
                    Icono(simbolo: "square.grid.3x3.fill", colores: [Color(white: 0.85), Color(white: 0.5)], tam: 48)
                }
                Divider().frame(height: 36)
                ForEach(AppID.allCases) { app in
                    Button { withAnimation(.spring(duration: 0.35, bounce: 0.5)) { e.abrir(app) } } label: {
                        Icono(app: app, tam: 48)
                            .overlay(alignment: .bottom) {
                                if e.ventanas.contains(where: { $0.app == app }) {
                                    Circle().fill(.white).frame(width: 4, height: 4).offset(y: 7)
                                }
                            }
                    }
                }
            }
            .padding(.horizontal, 10).padding(.vertical, 12)
        }
        .frame(height: 78)
        .frame(maxWidth: e.area.width > 600 ? 560 : 370)
        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .padding(.horizontal, 8).padding(.bottom, 8)
    }
}

struct LanzadorView: View {
    @Environment(Escritorio.self) private var e

    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea()
                .onTapGesture { withAnimation(.spring) { e.lanzador = false } }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 24) {
                ForEach(AppID.allCases) { a in
                    Button { withAnimation(.spring) { e.lanzador = false; e.abrir(a) } } label: {
                        VStack(spacing: 6) {
                            Icono(app: a, tam: 60)
                            Text(a.titulo).font(.caption).foregroundStyle(.white)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(24)
        }
    }
}

struct BusquedaView: View {
    @Environment(Escritorio.self) private var e
    @State private var q = ""
    @FocusState private var foco: Bool

    // Calculadora en la búsqueda: escribe por ejemplo 12*3
    private var calculo: String? {
        let t = q.replacingOccurrences(of: " ", with: "")
        guard let i = t.dropFirst().firstIndex(where: { "+-*/x×÷".contains($0) }) else { return nil }
        guard let a = Double(t[..<i]), let b = Double(t[t.index(after: i)...]) else { return nil }
        let r: Double
        switch t[i] {
        case "+": r = a + b
        case "-": r = a - b
        case "*", "x", "×": r = a * b
        default:
            if b == 0 { return nil }
            r = a / b
        }
        return r == r.rounded() && abs(r) < 1e12 ? String(Int(r)) : String(r)
    }

    private var apps: [AppID] { q.isEmpty ? [] : AppID.allCases.filter { $0.titulo.localizedCaseInsensitiveContains(q) } }
    private var archivos: [String] {
        q.isEmpty ? [] : ((try? FileManager.default.contentsOfDirectory(atPath: URL.documentsDirectory.path)) ?? [])
            .filter { $0.localizedCaseInsensitiveContains(q) }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Image(systemName: "magnifyingglass")
                TextField("Búsqueda", text: $q).focused($foco)
                    .onSubmit { if let a = apps.first { abrir(a) } }
            }
            .font(.title3).padding(14)
            if !apps.isEmpty || !archivos.isEmpty || calculo != nil {
                Divider()
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        if let c = calculo {
                            Label("= \(c)", systemImage: "equal.circle.fill")
                                .font(.title3.bold()).padding(.horizontal, 14).padding(.vertical, 8)
                        }
                        ForEach(apps) { a in
                            Button { abrir(a) } label: {
                                HStack { Icono(app: a, tam: 28); Text(a.titulo); Spacer() }
                                    .padding(.horizontal, 14).padding(.vertical, 6)
                            }
                            .buttonStyle(.plain)
                        }
                        ForEach(archivos, id: \.self) { f in
                            Label(f, systemImage: "doc").padding(.horizontal, 14).padding(.vertical, 6)
                        }
                    }
                }
                .frame(maxHeight: 260)
            }
        }
        .frame(maxWidth: 360)
        .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .padding(.horizontal, 12)
        .onAppear { foco = true }
    }

    private func abrir(_ a: AppID) {
        withAnimation(.spring) { e.busqueda = false }
        e.abrir(a)
    }
}

struct VistaGeneralView: View {
    @Environment(Escritorio.self) private var e

    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea()
                .onTapGesture { withAnimation(.spring) { e.vistaGeneral = false } }
            if e.ventanas.isEmpty {
                Text("No hay ventanas abiertas").foregroundStyle(.white)
            } else {
                ScrollView {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                        ForEach(e.ventanas) { v in
                            VStack(spacing: 8) {
                                Icono(app: v.app, tam: 56)
                                Text(v.app.titulo).font(.footnote.bold())
                                if v.minimizada { Text("Minimizada").font(.caption2).foregroundStyle(.secondary) }
                            }
                            .frame(maxWidth: .infinity, minHeight: 130)
                            .glassEffect(.regular, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                            .overlay(alignment: .topTrailing) {
                                Button { withAnimation(.spring) { e.cerrar(v) } } label: {
                                    Image(systemName: "xmark.circle.fill").font(.title3).padding(8)
                                }
                                .buttonStyle(.plain)
                            }
                            .contentShape(Rectangle())
                            .onTapGesture { withAnimation(.spring) { e.vistaGeneral = false; e.abrir(v.app) } }
                        }
                    }
                    .padding(20)
                }
                .padding(.top, 60)
            }
        }
    }
}
