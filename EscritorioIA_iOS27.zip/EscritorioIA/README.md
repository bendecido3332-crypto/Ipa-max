# EscritorioIA

Escritorio estilo macOS para iPhone, con asistente (Apple Intelligence on-device), voz y App Intents. Código original.

## Requisitos
Mac con Xcode 26, iPhone compatible con Apple Intelligence (iOS 26) con Apple Intelligence activado.

## Compilar
1. `brew install xcodegen`
2. En esta carpeta: `xcodegen`  (crea EscritorioIA.xcodeproj)
3. Abre el proyecto, en Signing & Capabilities elige tu Team y cambia el bundle id.
4. Conecta el iPhone y pulsa Run.
5. Para el .ipa: Product > Archive > Distribute App (Ad Hoc / Development).

Sin xcodegen: crea un proyecto iOS App nuevo en Xcode, borra ContentView, arrastra los .swift y añade
NSMicrophoneUsageDescription y NSSpeechRecognitionUsageDescription en Info.

## Prueba
- "Abre las notas" y "Guarda una nota: comprar leche" (el modelo usa sus herramientas).
- A Siri: "Pregunta a EscritorioIA".

## Apps incluidas
Asistente, Notas, Calculadora, Navegador (WebKit), Archivos y Terminal (sobre la carpeta Documentos de la app), Monitor del sistema y Ajustes (fondos y voz).

## .ipa sin Mac (GitHub Actions)
1. Sube el contenido de esta carpeta a un repositorio nuevo de GitHub (rama main).
2. Pestaña Actions > Build IPA > Run workflow.
3. Descarga el artefacto EscritorioIA-ipa. El .ipa sale SIN firmar.
4. Instálalo con Sideloadly o AltStore (te lo firman con tu Apple ID; caduca a los 7 días con cuenta gratuita).

## Centro de control
Toca el icono de sliders en la barra o desliza hacia abajo desde arriba. Controles reales: modo claro/oscuro, linterna, voz del asistente, brillo, volumen y accesos directos.
